#!/bin/bash

# Check if the destination directory exists
if [ ! -d "/usr/local/lib/python3.9/dist-packages/pwnagotchi/ui/" ]; then
    echo "Error: Destination directory does not exist."
    exit 1
fi

# Copy files to the destination directory using sudo
sudo cp components.py view.py faces.py /usr/local/lib/python3.9/dist-packages/pwnagotchi/ui/

# Check if the copy operation was successful
if [ $? -eq 0 ]; then
    echo "Files copied successfully."
else
    echo "Error copying files."
fi
